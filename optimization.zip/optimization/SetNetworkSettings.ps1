# Функция для изменения параметров адаптера
function Set-NetworkAdapterProperty {
    param (
        [string]$adapterName,
        [string]$propertyName,
        [string]$propertyValue
    )
    try {
        Set-NetAdapterAdvancedProperty -Name $adapterName -DisplayName $propertyName -DisplayValue $propertyValue
        Write-Host "Настройка для '$propertyName' установлена на '$propertyValue'."
    }
    catch {
        Write-Host "Ошибка при установке '$propertyName' на '$propertyValue': $_"
    }
}

# Получаем список всех сетевых адаптеров
$adapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }

foreach ($adapter in $adapters) {
    $adapterName = $adapter.Name
    Write-Host "Настраивается адаптер: $adapterName"

    # Общие настройки для всех адаптеров
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Advanced EEE" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Gigabit Lite" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Power Saving Mode" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Wake on magic packet when system is" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Auto-negotiation" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Jumbo Packet" -propertyValue "Disabled"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Transmit Buffers" -propertyValue "128"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Receive Buffers" -propertyValue "512"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Wake on LAN" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Pattern Matching" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Function Trigger" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "ARP Offload" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "NS Offload" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Green Ethernet" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Checksum Offload | Py4" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Checksum Offload TCP" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Checksum Offload UDP" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "RSS Maximum Queues" -propertyValue "4"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Interrupt Moderation" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Sideband Scaling" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "VLAN Priority" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Large Send Offload v2" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "TCP Large Send Offload v2" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Network Address" -propertyValue ""
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Flow Control" -propertyValue "Выкл"
    Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Energy Efficient Ethernet" -propertyValue "Выкл"

    if ($adapter.MediaType -eq "802.3") {
        # Настройки для Ethernet
        Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Speed & Duplex" -propertyValue "1 Gbps Full Duplex"
        Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Speed on Wake On LAN" -propertyValue "Do not use auto-speed reduction"
    }
    elseif ($adapter.MediaType -eq "802.11") {
        # Настройки для Wi-Fi
        Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Preferred Band" -propertyValue "5 GHz"
        Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Roaming Aggressiveness" -propertyValue "Lowest"
        Set-NetworkAdapterProperty -adapterName $adapterName -propertyName "Transmit Power" -propertyValue "Highest"
    }
    else {
        Write-Host "Тип адаптера $($adapter.MediaType) не поддерживается. Пропуск."
    }
}

Write-Host "Настройка завершена."